__author__ = 'pavan.tummalapalli'


class Error(Exception):
    """Base class for other exceptions"""
    pass