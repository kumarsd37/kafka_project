import time
current_time_in_milliseconds = lambda: int(round(time.time() * 1000))