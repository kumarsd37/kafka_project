__author__ = 'pavan.tummalapalli'

import logging

from kafka import KafkaConsumer, ConsumerRebalanceListener, OffsetAndMetadata, TopicPartition
from kafka.errors import KafkaError, CommitFailedError
from six import iteritems

from .meta import TopicPartitionOffset

from framework.abstract_client import AbstractConsumer

logger = logging.getLogger(__name__)


class Consumer(AbstractConsumer):

    def __init__(self, **kwargs):
        """
        constructor for consumer
        :keyword Arguments
        """

        # checking if kwargs are present
        assert kwargs, 'unrecognized configs'
        self.kwargs = kwargs

        # checking if kafka consumer client_config is present or not.
        assert kwargs.get('client_config'), 'unrecognized client config'
        self.client_config = kwargs.get('client_config')

        assert self.client_config.get('group_id'), 'group_id should not be None'

        # initialize the auto commit by getting the enable auto commit value from config
        # if client config has no auto commit set by default it will be False.
        self.enable_auto_commit = self.client_config.get('enable_auto_commit') or False

        # check if external
        self.enable_external_commit = kwargs.get('enable_external_commit')

        if self.enable_external_commit:
            assert kwargs.get('external_commit_config'), 'external commit config missing'
            self.external_commit_config = kwargs.get('external_commit_config')

        # we will pass internal commit or external commit to based upon the setting.
        self._commit = None

        # used at the time of consumer rebalanced
        self.handle_rebalance_listener = None

        assert kwargs.get('topics'), 'topics should not be none'
        self.topics = kwargs.get('topics')

        super().__init__()

        try:
            self.consumer_client = KafkaConsumer(**self.client_config)
            self.subscribe(topics=self.topics, listener=self.getRebalanceListener())

            if self.enable_auto_commit and self.enable_external_commit:
                raise Exception('cant commit to kafka and external simultaneously')
            elif self.enable_external_commit:

                try:
                    self.external_commit_client = self.create_external_commit_dao(self.external_commit_config)
                    self._commit = self.external_commit
                except (KeyError, Exception) as exc:
                    raise exc
            elif not self.enable_auto_commit:
                self._commit = self.internal_commit

        except KafkaError as exc:
            raise exc

    def subscribe(self, topics, listener=None):
        logger.info('subscribing to topics {}'.format(topics))
        if not topics and len(topics) <= 0:
            raise Exception('topics should not be none')
        try:
            self.consumer_client.subscribe(topics, listener=listener)
        except (KafkaError, Exception) as exc:
            raise exc

    def seek(self, topic_partition, offset):
        """
        seek to specific partition.

        :param topic_partition: topic_partition object consists of topic and offset
        :type topic_partition: TopicPartition
        :param offset: offset to seek
        :type offset: int

        """
        try:

            self.consumer_client.seek(topic_partition, offset)
        except KafkaError as exc:
            logger.exception('cant seek to specific offset')
            raise exc

    def assign(self, topic_partitions):
        """
        Manually assign a list of TopicPartitions to this consumer.

        :param topic_partitions: list of topic partition tuple
        :type topic_partitions: list
        :raises KafkaError
        """
        topic_partitions_list = list()
        for topic, partition in topic_partitions:
            tp = TopicPartition(topic, partition)
            topic_partitions_list.append(tp)
        try:
            self.consumer_client.assign(topic_partitions_list)
        except KafkaError as exc:
            logger.error(exc, exc_info=True)
            raise exc

    def assignment(self):
        """
        Get the TopicPartitions currently assigned to this consumer.

        If partitions were directly assigned using
        :meth:`~Consumer.assign`, then this will simply return the
        same partitions that were previously assigned.  If topics were
        subscribed using :meth:`~Consumer.subscribe`, then this will
        give the set of topic partitions currently assigned to the consumer
        (which may be None if the assignment hasn't happened yet, or if the
        partitions are in the process of being reassigned).

        :return: {TopicPartition, ...}
        :rtype: set
        """
        try:
            assignment = self.consumer_client.assignment()
            return assignment
        except KafkaError as exc:
            logger.error(exc, exc_info=True)
            raise exc

    def beginning_offsets(self, topic_partitions):
        """
        Get the first offset for the given partitions.
        This method does not change the current consumer position of the partitions.

        :param topic_partitions:
        :type TopicPartition
        .. note::
            This method may block indefinitely if the partition does not exist.

        :param list of topic_partitions)
        :type list
        :return: The earliest available offsets for the given partitions.
        :rtype: ({TopicPartition: int})
        :raises KafkaError
        """
        try:
            res = self.consumer_client.beginning_offsets(topic_partitions)
            return res
        except KafkaError as exc:
            raise exc

    def seek_to_beginning(self, topic_partitions):
        """
        seek to beginning of the partitions
        :param topic_partitions:
        :type topic_partitions:
        :return:
        :rtype:
        """
        try:
            res = self.consumer_client.seek_to_beginning(topic_partitions)
            return res
        except KafkaError as exc:
            raise exc

    def pre_consume(self, *args, **kwargs):
        pass

    def consume(self, *args, **kwargs):
        timeout = kwargs.get('timeout') or self.kwargs.get('timeout') or 5
        max_records = kwargs.get('max_records') or self.kwargs.get('max_records') or 5
        try:
            records = iteritems(self.consumer_client.poll(timeout_ms=timeout, max_records=max_records))
            messages = []
            for record in records:
                if record is not None:
                    logger.debug(record)
                    # message returns tuple of (TopicPartition, list(ConsumerRecord)
                    for consumerRecord in record[1]:
                        logger.debug(consumerRecord)
                        messages.append(consumerRecord)
            return messages

        except (KafkaError, Exception) as exc:
            raise exc

    def post_consume(self, *args, **kwargs):
        if self._commit:
            message = args[0]
            topic_partition_offset = TopicPartitionOffset(message.topic, message.partition, message.offset)
            try:
                self.commit(topic_partition_offset)
            except Exception as exc:
                logger.error(exc.__str__())

    @staticmethod
    def create_external_commit_dao(config):
        from utils.caching.redis_pool import RedisPoolConnection
        from .redis_commit import KafkaRedisOffsetCommitDAO
        try:
            redis_config = config['redis']['client_config']
            namespace = config.get('redis').get('namespace')
            delimiter = config['redis'].get('delimiter') or ':'
            redis_pooled_connection = RedisPoolConnection(**redis_config)
            kafka_redis_offset_commit_dao = KafkaRedisOffsetCommitDAO(redis_pooled_connection, namespace=namespace, delimiter=delimiter)
            return kafka_redis_offset_commit_dao
        except (KeyError, Exception) as exc:
            logger.error(exc.__str__())
            raise exc

    def external_commit(self, topic_partition_offset=None):
        try:
            response = self.external_commit_client.commit_offset(topic_partition_offset)
            if not response:
                raise Exception('kafka external commit failed for topic:{}, partition:{} and offset:{}'.format(topic_partition_offset.topic, topic_partition_offset.partition, topic_partition_offset.offset))
        except (ConnectionError, TimeoutError, Exception) as exc:
            logger.exception(str(exc))
            raise exc

    def internal_commit(self, topic_partition_offset):
        """
                commit the last read offsets

                :param topic_partition_offset: list of topic, partition, tuple
                :type topic_partition_offset: list
                :raises CommitFailedError
        """
        if topic_partition_offset is not None:
            offsets = {
                TopicPartition(topic_partition_offset.topic, topic_partition_offset.partition): OffsetAndMetadata(
                    topic_partition_offset.offset + 1, None)
            }
        else:
            offsets = None
        try:
            self.consumer_client.commit(offsets=offsets)
        except CommitFailedError as exc:
            raise exc

    def commit(self, topic_partition_offset=None):
        self._commit(topic_partition_offset)

    def commit_async(self, offsets=None, callback=None):
        """
        Commit offsets to kafka_client asynchronously, optionally firing callback.
        This commits offsets only to Kafka.
        The offsets committed using this API will be used on the first fetch after every rebalance and also on startup.
        As such, if you need to store offsets in anything other than Kafka, this API should not be used.
        To avoid re-processing the last message read if a consumer is restarted, the committed offset should be the next message your application should consume, i.e.: last_offset + 1.

        :param offsets: dictionary of TopicPartition and OffsetAndMetadata
        :type offsets: (dict or None)
        :param: Called as callback(offsets, response)
        :type: (function or None)
        :return future object
        :rtype Future
        """
        try:
            self.consumer_client.commit_async(offsets, callback)
        except KafkaError as exc:
            raise exc

    def partitions_for_topic(self, topic):
        """
        Get metadata about the partitions for a given topic.

        :param topic: Topic to check.
        :type topic: str
        :return: Partition ids
        :rtype: set
        """
        try:
            partitions = self.consumer_client.partitions_for_topic(topic)
            return partitions
        except KafkaError as exc:
            raise exc

    def on_partitions_assigned(self, assigned):
        if self.enable_external_commit:
            for tp in assigned:
                topic = tp.topic
                partition = tp.partition
                tpo = self.external_commit_client.get_topic_partition_offset(TopicPartitionOffset(topic, partition, None))
                logger.info('last committed offset for topic:{} , partition:{} is {}'.format(topic, partition, tpo.offset))
                if tpo.offset:
                    self.consumer_client.seek(tp, tpo.offset)
                    
    def on_partitions_revoked(self, revoked):
        pass

    def getRebalanceListener(self):
        """ return the object of ConsumerRebalanceListener  """

        HandleRebalanceListener = type('HandleRebalanceListener', (ConsumerRebalanceListener,),
            {
                'on_partitions_assigned': self.on_partitions_assigned,
                'on_partitions_revoked': self.on_partitions_revoked
             }
        )
        
        self.handle_rebalance_listener = HandleRebalanceListener()
        return self.handle_rebalance_listener
        
    def deserialize_message(self, message, *args, **kwargs):
        pass

    def close(self, *args, **kwargs):
        """
        Close the consumer, we can commit the messages if needed before closing.
        """
        if kwargs.get('autocommit') is not None:
            autocommit = kwargs.get('autocommit')
        else:
            autocommit = False
        logger.info('closing consumer....')
        self.consumer_client.close(autocommit)







