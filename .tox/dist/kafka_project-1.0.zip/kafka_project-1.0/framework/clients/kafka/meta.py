__author__ = 'pavan.tummalapalli'

from collections import namedtuple

TopicPartitionOffset = namedtuple('TopicPartitionOffset', ['topic', 'partition', 'offset'])

