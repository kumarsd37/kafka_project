__author__ = 'pavan.tummalapalli'

from framework.clients.file.file_writer import FileWriter

__all__ = ['FileWriter']